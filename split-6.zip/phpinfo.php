<?php echo phpinfo();
?>